var phoneNode = document.getElementById("number");
phoneNode.addEventListener("change", chkPhone, false);
var emailNode = document.getElementById("email");
emailNode.addEventListener("change", chkEmail, false);